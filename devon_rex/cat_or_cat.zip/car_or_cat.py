import os

def strings_to_binary(flag):
    flag_bin = ''.join([format(ord(char), '08b') for char in flag])
    return flag_bin

def binary_to_hex(flag):
    return ''.join([hex(int(flag[i:i+8], 2))[2:].zfill(2) for i in range(0, len(flag), 8)])

def xor(flag_bin, key_bin):
    xor_result = [int(flag_bin[i]) ^ int(key_bin[i % len(key_bin)]) for i in range(len(flag_bin))]
    return binary_to_hex(''.join(map(str, xor_result)))

FLAG = 'mlsc{FAKE_FLAG_;)}'
key = os.urandom(5)
key_bin = ''.join([format(byte, '08b') for byte in key])
text = strings_to_binary(FLAG)
print(xor(text, key_bin))

