import argparse
from PIL import Image

def text_to_binary(text):
    return ''.join(format(ord(c), '08b') for c in text)

def binary_to_text(binary):
    binary_values = [binary[i:i+8] for i in range(0, len(binary), 8)]
    ascii_characters = [chr(int(b, 2)) for b in binary_values]
    return ''.join(ascii_characters)

def embed(image_path, data):
    image = Image.open(image_path)
    binary_data = text_to_binary(data)
    data_len = len(binary_data)

    if image.mode != 'RGB':
        raise ValueError("Image mode should be RGB")

    pixels = list(image.getdata())
    new_pixels = []

    data_index = 0
    for pixel in pixels:
        if data_index < data_len:
            r, g, b = pixel
            new_r = r & ~1 | int(binary_data[data_index])
            new_pixels.append((new_r, g, b))
            data_index += 1
        else:
            new_pixels.append(pixel)

    new_image = Image.new(image.mode, image.size)
    new_image.putdata(new_pixels)
    return new_image

def main():
    parser = argparse.ArgumentParser(description='encode')
    subparser = parser.add_subparsers(dest='command')

    embed_parser = subparser.add_parser('embed')
    embed_parser.add_argument('-cf', required=True, help='Image Path')
    embed_parser.add_argument('-t', required=True, help='Data')

    args = parser.parse_args()

    if args.command == 'embed':
        image_with_data = embed(args.cf, args.t)
        image_with_data.save("encoded_image.png")

if __name__ == '__main__':
    main()


